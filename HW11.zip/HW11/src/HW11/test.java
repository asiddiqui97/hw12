//  this program uses an array and collects information such as name and birthdate. 
//This program allows user to modify the persons information.
//Author: Aman Siddiqui
package HW11;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		ArrayList<info> entries = new ArrayList<>();

		entries.add(new info("Aman", "09/02/97", "630-620-8578", "Siddiui1@gmail.com"));
		entries.add(new info("sam", "01/01/91", "630-258-9865", "sam2@gmail.com"));
		entries.add(new info("jordan", "12/25/85", "630-985-4512", "jordan23@gmail.com"));
		entries.add(new info("john", "03/06/75", "630-845-2156", "john24@gmail.com"));
		entries.add(new info("Doe", "04/07/89", "630-930-0325", "Doe@gmail.com"));
		entries.add(new info("hank", "08/12/05", "630-256-3621", "hank54@gmail.com"));

		while (true) {
			menu();
			int x = new Scanner(System.in).nextInt();
			switch (x) {
			case 1:
				addInformation(entries);
				break;
			case 2:
				for (info i : retrieveInformation()) {
					System.out.println(i);
				}

				break;
			case 3:
				deleteInformation();
				break;
			case 4:
				updateInformation();
				break;
			case 5:
				System.exit(0);
				break;
			default:
				System.out.println("sorry, that is an invalid input");
			}
		}
	}

	public static void addInformation(ArrayList<info> entries) {
		try {
			FileOutputStream f = new FileOutputStream("info.txt");
			ObjectOutputStream out = new ObjectOutputStream(f);
			out.writeObject(entries);
			out.close();
			f.close();
		} catch (IOException ex) {
			System.out.println("Error");
		}
		System.out.println("Data is saved successfully");
	}

	public static ArrayList<info> retrieveInformation() {
		ArrayList<info> entries = null;
		try {
			FileInputStream f = new FileInputStream("info.txt");
			ObjectInputStream input = new ObjectInputStream(f);
			entries = (ArrayList<info>) input.readObject();
			input.close();
			f.close();
		} catch (IOException ex) {
			System.out.println("Error");
		} catch (ClassNotFoundException ctch) {
			ctch.printStackTrace();
		}
		System.out.println("success!");
		return entries;
	}

	public static void deleteInformation() {
		ArrayList<info> entries = retrieveInformation();
		System.out.print("Enter which name you would like to delete ");
		String name = new Scanner(System.in).nextLine();

		for (info ind : entries) {
			if (ind.getName().equalsIgnoreCase(name)) {
				entries.remove(ind);
				addInformation(entries);
				System.out.println("delete the chosen individual");
				return;
			}
		}
		System.out.println("Error, not found");
	}

	public static void updateInformation() {
		ArrayList<info> entries = retrieveInformation();
		System.out.print("Enter which name you would like to delete ");
		String name = new Scanner(System.in).nextLine();

		for (info ind : entries) {
			if (ind.getName().equalsIgnoreCase(name)) {
				String birthday, email, num;
				System.out.print("Enter date of birth: ");
				birthday = new Scanner(System.in).nextLine();
				System.out.print("Enter email: ");
				email = new Scanner(System.in).nextLine();
				System.out.println("Enter a phone number: ");
				
				num = new Scanner(System.in).nextLine();
				entries.set(entries.indexOf(ind), new info(name, birthday, num, email));
				addInformation(entries);
				System.out.println("Update info");
				return;
			}
		}
		System.out.println("Error,not found");
	}

	public static void menu() {
		System.out.println("Press 1 to Add Information to a file");
		System.out.println("Press 2 to Load Information from a file");
		System.out.println("Press 3 to Delete Information");
		System.out.println("Press 4 to Update Information");
		System.out.println("Press 5 to Exit");

	}

}
