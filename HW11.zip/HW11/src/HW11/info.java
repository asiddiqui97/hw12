//Info class for main class test
package HW11;

import java.io.Serializable;

public class info implements Serializable {
	
    private String name, birthday, num, email;

    public info(String name, String birthday, String num, String email) {
        this.name = name;
        this.birthday = birthday;
        this.num = num;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
    	
        return "Name: " + name +
                "\nDate of Birth: " + birthday +
                "\nPhone Number: " + num +
                "\nEmail Address: " + email;
    }
}
